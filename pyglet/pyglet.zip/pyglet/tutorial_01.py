# 01 : create a window
import pyglet

window = pyglet.window.Window(800, 400)
pyglet.app.run()