import pyglet

win = pyglet.window.Window()

for target_list in expression_list:
    pass
else:
    pass

for target_list in expression_list:
    pass
else:
    pass